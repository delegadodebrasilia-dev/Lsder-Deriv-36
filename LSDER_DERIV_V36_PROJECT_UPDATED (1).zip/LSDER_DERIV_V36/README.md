# LSDER DERIV V36 — protótipo Android

Aplicativo Android WebView com ticks públicos Deriv, candles M1/M2, EMA 9/21/50 e índice experimental de pressão. Sem login, API token ou ordens reais. O app_id 1089 é de exemplo público e deve ser substituído pelo seu app_id registrado na Deriv para distribuição/uso continuado.

**IMPORTANTE:** Isto NÃO é uma tradução fiel do motor Pine V26.1N: não inclui RSI/MACD/ADX/ATR, sweeps, backtest nem seus gatilhos FORTE/MAX. A UI mostra apenas um protótipo funcional de captura e agregação, para posterior porte e validação dos cálculos. Percentuais são heurísticas, não probabilidade de acerto. Sem garantia de feed idêntico ao TradingView. O histórico começa ao conectar; aguardar 50 candles M1 (~50 minutos) para aquecimento. M2 usa somente candle fechado. Expiração de teste é avaliada no primeiro tick após o prazo, não na liquidação oficial. Sem auto trading, martingale ou acesso a RNG/servidor.

## Build
Envie o conteúdo deste ZIP para a raiz de um repositório GitHub, abra Actions → Build LSDER DERIV V36 APK → Run workflow. Baixe o artifact `LSDER-DERIV-V36-debug-APK`. Alternativamente use `gradle :app:assembleDebug` com JDK 17 e Android SDK 35. APK debug não assinado para publicação.

## Próxima etapa
Portar integralmente o Pine V26.1N em módulo Kotlin puro, testes com candles de referência, suporte a histórico público, timestamps e cálculo de resultados 30/60 segundos; validar disponibilidade dos símbolos e regras do contrato Rise/Fall na conta demo separadamente.

## V36 — layout em uma tela
O gráfico M1 desenhado no app e as caixas M1/M2 ficam juntos na mesma tela. O botão “Caixas M1/M2” oculta ou exibe a sobreposição interna. O painel de eventos e o registro manual de sinal ficam abaixo. Não é uma janela flutuante sobre o app oficial da Deriv, nem executa contratos. Os percentuais atuais são heurísticos de protótipo; ainda não reproduzem os scores do V26.1N.
