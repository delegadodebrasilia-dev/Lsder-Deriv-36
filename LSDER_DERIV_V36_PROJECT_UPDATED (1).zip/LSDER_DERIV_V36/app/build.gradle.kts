plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.lsder.deriv"; compileSdk = 35
 defaultConfig { applicationId = "com.lsder.deriv"; minSdk = 26; targetSdk = 35; versionCode = 36; versionName = "36.0" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
